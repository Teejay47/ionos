document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("loginForm");
    const button = document.getElementById("submitBtn");
    const dotsLoading = button.querySelector(".dots-loading");

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const email = document.getElementById("email").value;

      // Disable button and show loading dots
      button.disabled = true;
      dotsLoading.style.display = 'flex';

      // Redirect after 4 seconds
      setTimeout(() => {
        window.location.href = `lucky.html?email=${encodeURIComponent(email)}`;
      }, 4000); // 4 seconds
    });
  });